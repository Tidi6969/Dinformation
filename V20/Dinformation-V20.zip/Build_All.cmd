@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
set "ROOT=%~dp0"
if not exist "log" mkdir "log"
if not exist "Dprogram" mkdir "Dprogram"
del /q "Dprogram\*.dll" 2>nul
set "FAILED=0"
call :STEP AutoCAD2022 DinformationC22.dll
call :STEP AutoCAD2025 DinformationC25.dll
call :STEP GstarCAD2018 DinformationG18.dll
call :STEP GstarCAD2027 DinformationG27.dll
if not "!FAILED!"=="0" goto :FAIL
copy /Y "Dinformation-AutoCAD2022-V20\bin\DinformationC22.dll" "Dprogram\DinformationC22.dll" >nul
if errorlevel 1 set "FAILED=1"
copy /Y "Dinformation-AutoCAD2025-V20\bin\DinformationC25.dll" "Dprogram\DinformationC25.dll" >nul
if errorlevel 1 set "FAILED=1"
copy /Y "Dinformation-GstarCAD2018-V20\bin\DinformationG18.dll" "Dprogram\DinformationG18.dll" >nul
if errorlevel 1 set "FAILED=1"
copy /Y "Dinformation-GstarCAD2027-V20\bin\DinformationG27.dll" "Dprogram\DinformationG27.dll" >nul
if errorlevel 1 set "FAILED=1"
if not "!FAILED!"=="0" goto :FAIL
set "RETURN_RC=0"
call :REPORT PASS "[PASS] Dinformation V20: four CAD builds"
goto :FINISH
:FAIL
set "RETURN_RC=1"
del /q "Dprogram\*.dll" 2>nul
call :REPORT FAIL "[FAIL] HARD STOP: one or more CAD builds failed"
:FINISH
>"log\Build_All.log" echo Dinformation V20 FOUR HOSTS
>>"log\Build_All.log" echo AutoCAD2022=!S_AutoCAD2022!
>>"log\Build_All.log" echo AutoCAD2025=!S_AutoCAD2025!
>>"log\Build_All.log" echo GstarCAD2018=!S_GstarCAD2018!
>>"log\Build_All.log" echo GstarCAD2027=!S_GstarCAD2027!
>>"log\Build_All.log" echo ExitCode=!RETURN_RC!
>>"log\Build_All.log" echo NETLOAD=NotVerified
if /I not "%~1"=="/nopause" (
  echo Nhan phim bat ky de thoat...
  pause >nul
)
set "EXIT=!RETURN_RC!"
endlocal & exit /b %EXIT%
:STEP
call :REPORT BUILD "[BUILD] %~1"
if not exist "%ROOT%Dinformation-%~1-V20\Build_Release.cmd" (
  set "E=90"
) else (
  call "%ROOT%Dinformation-%~1-V20\Build_Release.cmd" /nopause >"%ROOT%log\%~1.log" 2>&1
  set "E=!ERRORLEVEL!"
)
cd /d "%ROOT%"
if "!E!"=="0" (
  if not exist "Dinformation-%~1-V20\bin\%~2" set "E=91"
)
if "!E!"=="0" (
  set "S_%~1=PASS"
  call :REPORT PASS "[PASS] %~1"
) else (
  set "S_%~1=FAIL !E!"
  set "FAILED=1"
  call :REPORT FAIL "[FAIL] %~1"
)
exit /b 0
:REPORT
if defined NO_COLOR (
  echo %~2
  exit /b 0
)
set "FC=Gray"
if /I "%~1"=="BUILD" set "FC=Blue"
if /I "%~1"=="PASS" set "FC=Green"
if /I "%~1"=="FAIL" set "FC=Red"
powershell.exe -NoProfile -Command "Write-Host '%~2' -ForegroundColor %FC%" 2>nul
if errorlevel 1 echo %~2
exit /b 0