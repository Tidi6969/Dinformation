DINFORMATION V20 - 4 HOST SOURCE / BUILD CANDIDATE
AutoCAD 2022 has the recognition improvements from V19.
AutoCAD 2025, GstarCAD 2018 and GstarCAD 2027 source retained from V17.
All four hosts build separately using their host-specific Reference/SDK.
NETLOAD and CAD runtime tests remain NotVerified; ReleaseApproved=NO.
