@echo off
setlocal EnableExtensions EnableDelayedExpansion
pushd "%~dp0"
if not exist "log" mkdir "log"
if not exist "Dprogram" mkdir "Dprogram"
if exist "Dprogram\DinformationC22.dll" del /q "Dprogram\DinformationC22.dll"
set "RC=1"
call :PRINT "TITLE" "Dinformation V18 - AutoCAD 2022"
call :PRINT "BUILD" "[BUILD] AutoCAD 2022 Release x64"
call "%~dp0Dinformation-AutoCAD2022-V18\Build_Release.cmd" /nopause >"log\AutoCAD2022.log" 2>&1
cd /d "%~dp0"
set "RC=!ERRORLEVEL!"
if not "!RC!"=="0" goto :FINISH
if not exist "Dinformation-AutoCAD2022-V18\bin\DinformationC22.dll" (
    set "RC=2"
    goto :FINISH
)
copy /Y "Dinformation-AutoCAD2022-V18\bin\DinformationC22.dll" "Dprogram\DinformationC22.dll" >nul
if errorlevel 1 (
    set "RC=3"
    goto :FINISH
)
set "RC=0"
:FINISH
>"log\Build_All.log" echo Dinformation V18 - AutoCAD 2022
>>"log\Build_All.log" echo Target=AutoCAD2022
>>"log\Build_All.log" echo BuildExitCode=!RC!
>>"log\Build_All.log" echo RuntimeStatus=NotVerified
if "!RC!"=="0" (
    call :PRINT "PASS" "[PASS] BUILD ALL: PASS - AutoCAD 2022"
) else (
    call :PRINT "FAIL" "[FAIL] BUILD ALL: FAIL - AutoCAD 2022"
)
echo Log: %~dp0log\Build_All.log
set "FINAL_RC=!RC!"
if /I not "%~1"=="/nopause" (
    echo Nhan phim bat ky de thoat...
    pause >nul
)
popd
endlocal & exit /b %FINAL_RC%
:PRINT
if defined NO_COLOR (
    echo COLOR_MODE=PLAIN; REASON=NO_COLOR
    echo %~2
    exit /b 0
)
set "COLOR=Gray"
if /I "%~1"=="TITLE" set "COLOR=Cyan"
if /I "%~1"=="BUILD" set "COLOR=Blue"
if /I "%~1"=="PASS" set "COLOR=Green"
if /I "%~1"=="FAIL" set "COLOR=Red"
if /I "%~1"=="WARNING" set "COLOR=Yellow"
powershell.exe -NoProfile -Command "Write-Host '%~2' -ForegroundColor %COLOR%" 2>nul
if errorlevel 1 (
    echo COLOR_MODE=PLAIN; REASON=COLOR_UNAVAILABLE
    echo %~2
)
exit /b 0