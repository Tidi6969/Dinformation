# Dinformation V19 - AutoCAD 2022 SOURCE / PENDING CAD TEST

Baseline: V18. Target: AutoCAD 2022 only.
Source patch: native PointMonitor pick with LISP fallback and safe unknown-object metadata.
Build: PASS Release x64, framework net48, SDK Autodesk 24.1.
NETLOAD / real AutoCAD 2022 tooltip tests: NotVerified.
Standards / release approval: NotVerified / NO.
Dprogram/DinformationC22.dll was built from V19 source; reference SDK DLLs are build-time only.
GstarCAD 2018, AutoCAD 2025, GstarCAD 2027: outside this package and unchanged in archived V18.
This is a source/build candidate for user CAD testing, NOT a completed V19 release.
