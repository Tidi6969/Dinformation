# Dinformation V29 — V23 native hover + V27 Dtag tooltip (source candidate)

**Source base:** owner-supplied Dinformation V27 ZIP; the three modified hover
sessions are rebuilt from their original V23 `InformationSession.cs` to keep the
same CAD-native pick/highlight/forced-pick sequence, adding only the read-only
Dtag integration already used by V27. V28 is NOT used as a source.

## Scope and principle (DCAD-STD-18)

- AutoCAD 2022, AutoCAD 2025, GstarCAD 2027: native `PointMonitor`,
  `GetPickedEntities()`, `TurnForcedPickOn()` and `GetPoint()` are **byte-for-byte
  method-body matches to V23**. No custom cursor hit-test. No change to any
  CAD `PICKBOX`, `OSMODE`, `APERTURE` or `SELECTIONPREVIEW` system variable.
- One *native CAD tooltip*: CAD properties for all objects, plus a translated
  Dtag information section on those with RegApp `my_tag` XData.
- On first hover over an object, build one tooltip once (including Dtag data if
  present) and cache it, including the case without XData. Each subsequent
  cursor event only reuses the string, as in V23. Cache is invalidated when
  that database object is modified. XData is read-only; no extra click.
- Preserve the V27 line-wrapping logic; no character truncation. Tooltip maximum
  height remains controlled by the CAD host and monitor. Large datasets might
  exceed available on-screen height.
- GstarCAD 2018: original V27 source, language files, templates and References
  are unchanged. Only packaging/build version labels are moved to V29.

**Important limitation:** Autodesk documents that forced picking while `GetPoint`
is active and OSNAP is enabled may use `APERTURE` instead of `PICKBOX`. This
was *also true in V23*. This release does not override CAD preferences to hide
that behavior. Test with OSNAP enabled and disabled; this is distinct from a
regression in the software's native hit-test logic.

## Build / status

Run `Build_All.cmd` on Windows with the appropriate host SDK/reference files.
The ZIP includes source and references but **no compiled DLLs**. The portable
outputs, if all builds succeed, are `Dprogram/DinformationC22.dll`,
`DinformationC25.dll`, `DinformationG18.dll`, `DinformationG27.dll`.

- Static source/ZIP checks: performed before packaging.
- Windows build (all four hosts): **NotVerified**.
- NETLOAD, runtime, hover sensitivity, PICKBOX/APERTURE behavior: **NotVerified**.
- ReleaseApproved=NO. Do not call this candidate a verified build.

Regression checklist: hover with no click; ordinary and tagged entities; with
OSNAP on/off and varying PICKBOX; compare with original V23 in the same drawing
and CAD settings; check long XYZ/XData; edit Dtag and verify cache invalidation;
confirm GstarCAD 2018 behaves as before.
