using System.Collections.Generic;
using System.Text;

namespace DCAD.Dinformation.UI
{
    internal sealed class TooltipFormatter
    {
        private readonly List<string> _lines = new List<string>();

        public void Add(string label, string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return;
            }

            _lines.Add(string.IsNullOrWhiteSpace(label) ? value : label + ": " + value);
        }

        public void AddRaw(string value)
        {
            if (!string.IsNullOrWhiteSpace(value))
            {
                _lines.Add(value);
            }
        }

        public override string ToString()
        {
            var builder = new StringBuilder();
            for (int i = 0; i < _lines.Count; i++)
            {
                if (i > 0)
                {
                    builder.AppendLine();
                }

                builder.Append(_lines[i]);
            }

            return builder.ToString();
        }
    }
}
