using System;
using System.Globalization;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using DCAD.Dinformation.UI;
using DCAD.Dinformation.Core;

namespace DCAD.Dinformation.Information
{
    internal sealed class ObjectInformationService
    {
        private const int Precision = 4;

        public string Build(Database database, ObjectId objectId)
        {
            if (database == null || objectId.IsNull || !objectId.IsValid || objectId.IsErased)
            {
                return string.Empty;
            }

            using (Transaction transaction = database.TransactionManager.StartOpenCloseTransaction())
            {
                var entity = transaction.GetObject(objectId, OpenMode.ForRead, false) as Entity;
                if (entity == null)
                {
                    return string.Empty;
                }

                var text = new TooltipFormatter();
                string dxfName = entity.GetRXClass() != null ? entity.GetRXClass().DxfName : entity.GetType().Name;

                text.AddRaw("[" + GetDisplayType(entity, dxfName) + "]");
                text.Add(Lang.T("LabelLayer"), Safe(() => entity.Layer));
                text.Add(Lang.T("LabelHandle"), Safe(() => entity.Handle.ToString()));

                AppendSpecificInformation(text, entity, dxfName, transaction);
                transaction.Commit();
                return text.ToString();
            }
        }

        private static void AppendSpecificInformation(
            TooltipFormatter text,
            Entity entity,
            string dxfName,
            Transaction transaction)
        {
            var line = entity as Line;
            if (line != null)
            {
                Vector3d vector = line.EndPoint - line.StartPoint;
                double angle = Math.Atan2(vector.Y, vector.X);
                text.Add(Lang.T("Length"), N(line.Length));
                text.Add(Lang.T("Angle"), Degree(angle));
                text.Add(Lang.T("StartPoint"), P(line.StartPoint));
                text.Add(Lang.T("EndPoint"), P(line.EndPoint));
                return;
            }

            var circle = entity as Circle;
            if (circle != null)
            {
                text.Add(Lang.T("Radius"), N(circle.Radius));
                text.Add(Lang.T("Diameter"), N(circle.Radius * 2.0));
                text.Add(Lang.T("Circumference"), N(2.0 * Math.PI * circle.Radius));
                text.Add(Lang.T("Area"), N(Math.PI * circle.Radius * circle.Radius));
                text.Add(Lang.T("Center"), P(circle.Center));
                return;
            }

            var arc = entity as Arc;
            if (arc != null)
            {
                text.Add(Lang.T("Radius"), N(arc.Radius));
                text.Add(Lang.T("ArcAngle"), Degree(arc.TotalAngle));
                text.Add(Lang.T("StartAngle"), Degree(arc.StartAngle));
                text.Add(Lang.T("EndAngle"), Degree(arc.EndAngle));
                text.Add(Lang.T("ArcLength"), N(arc.Length));
                text.Add(Lang.T("Center"), P(arc.Center));
                return;
            }

            var polyline = entity as Polyline;
            if (polyline != null)
            {
                text.Add(Lang.T("VertexCount"), polyline.NumberOfVertices.ToString(CultureInfo.InvariantCulture));
                text.Add(Lang.T("Closed"), YesNo(polyline.Closed));
                text.Add(Lang.T("Length"), SafeNumber(() => polyline.Length));
                if (polyline.Closed)
                {
                    text.Add(Lang.T("Area"), SafeNumber(() => polyline.Area));
                }
                text.Add(Lang.T("ConstantWidth"), SafeNumber(() => polyline.ConstantWidth));
                return;
            }

            var block = entity as BlockReference;
            if (block != null)
            {
                text.Add(Lang.T("BlockName"), GetBlockName(block, transaction));
                text.Add(Lang.T("InsertionPoint"), P(block.Position));
                text.Add(Lang.T("ScaleX"), N(block.ScaleFactors.X));
                text.Add(Lang.T("ScaleY"), N(block.ScaleFactors.Y));
                text.Add(Lang.T("ScaleZ"), N(block.ScaleFactors.Z));
                text.Add(Lang.T("Rotation"), Degree(block.Rotation));
                text.Add(Lang.T("AttributeCount"), block.AttributeCollection.Count.ToString(CultureInfo.InvariantCulture));
                return;
            }

            var attributeReference = entity as AttributeReference;
            if (attributeReference != null)
            {
                text.Add(Lang.T("Tag"), attributeReference.Tag);
                text.Add(Lang.T("Value"), attributeReference.TextString);
                text.Add(Lang.T("Height"), N(attributeReference.Height));
                text.Add(Lang.T("Rotation"), Degree(attributeReference.Rotation));
                text.Add(Lang.T("TextStyle"), GetTextStyleName(attributeReference.TextStyleId, transaction));
                return;
            }

            var attributeDefinition = entity as AttributeDefinition;
            if (attributeDefinition != null)
            {
                text.Add(Lang.T("Tag"), attributeDefinition.Tag);
                text.Add(Lang.T("Prompt"), attributeDefinition.Prompt);
                text.Add(Lang.T("Default"), attributeDefinition.TextString);
                text.Add(Lang.T("Height"), N(attributeDefinition.Height));
                text.Add(Lang.T("Rotation"), Degree(attributeDefinition.Rotation));
                text.Add(Lang.T("TextStyle"), GetTextStyleName(attributeDefinition.TextStyleId, transaction));
                return;
            }

            var dbText = entity as DBText;
            if (dbText != null)
            {
                text.Add(Lang.T("Content"), dbText.TextString);
                text.Add(Lang.T("Height"), N(dbText.Height));
                text.Add(Lang.T("WidthFactor"), N(dbText.WidthFactor));
                text.Add(Lang.T("Rotation"), Degree(dbText.Rotation));
                text.Add(Lang.T("TextStyle"), GetTextStyleName(dbText.TextStyleId, transaction));
                text.Add(Lang.T("Position"), P(dbText.Position));
                return;
            }

            var mText = entity as MText;
            if (mText != null)
            {
                text.Add(Lang.T("Content"), OneLine(mText.Text));
                text.Add(Lang.T("Height"), N(mText.TextHeight));
                text.Add(Lang.T("Rotation"), Degree(mText.Rotation));
                text.Add(Lang.T("TextStyle"), GetTextStyleName(mText.TextStyleId, transaction));
                text.Add(Lang.T("Position"), P(mText.Location));
                return;
            }

            var dimension = entity as Dimension;
            if (dimension != null)
            {
                text.Add(Lang.T("Measurement"), SafeNumber(() => dimension.Measurement));
                text.Add(Lang.T("TextOverride"), string.IsNullOrEmpty(dimension.DimensionText) ? Lang.T("None") : dimension.DimensionText);
                text.Add(Lang.T("DimStyle"), GetDimStyleName(dimension.DimensionStyle, transaction));
                text.Add(Lang.T("TextPosition"), P(dimension.TextPosition));
                return;
            }

            var ellipse = entity as Ellipse;
            if (ellipse != null)
            {
                text.Add(Lang.T("MajorRadius"), N(ellipse.MajorRadius));
                text.Add(Lang.T("MinorRadius"), N(ellipse.MinorRadius));
                text.Add(Lang.T("StartAngle"), Degree(ellipse.StartAngle));
                text.Add(Lang.T("EndAngle"), Degree(ellipse.EndAngle));
                text.Add(Lang.T("Closed"), YesNo(ellipse.Closed));
                text.Add(Lang.T("Center"), P(ellipse.Center));
                if (ellipse.Closed)
                {
                    text.Add(Lang.T("Area"), SafeNumber(() => ellipse.Area));
                }
                return;
            }

            var hatch = entity as Hatch;
            if (hatch != null)
            {
                text.Add(Lang.T("Pattern"), hatch.PatternName);
                text.Add(Lang.T("Angle"), Degree(hatch.PatternAngle));
                text.Add(Lang.T("Scale"), N(hatch.PatternScale));
                text.Add(Lang.T("Associative"), YesNo(hatch.Associative));
                text.Add(Lang.T("HatchStyle"), hatch.HatchStyle.ToString());
                // Hover path: skip Hatch.Area because the reference LISP does not calculate it.
                return;
            }

            var leader = entity as Leader;
            if (leader != null)
            {
                text.Add(Lang.T("VertexCount"), leader.NumVertices.ToString(CultureInfo.InvariantCulture));
                text.Add(Lang.T("HasArrowHead"), YesNo(leader.HasArrowHead));
                text.Add(Lang.T("DimStyle"), GetDimStyleName(leader.DimensionStyle, transaction));
                return;
            }

            var spline = entity as Spline;
            if (spline != null)
            {
                text.Add(Lang.T("Degree"), spline.Degree.ToString(CultureInfo.InvariantCulture));
                text.Add(Lang.T("Closed"), YesNo(spline.Closed));
                text.Add(Lang.T("Length"), CurveLength(spline));
                if (spline.Closed)
                {
                    text.Add(Lang.T("Area"), SafeNumber(() => spline.Area));
                }
                return;
            }

            var region = entity as Region;
            if (region != null)
            {
                text.Add(Lang.T("Area"), SafeNumber(() => region.Area));
                return;
            }

            var solid3d = entity as Solid3d;
            if (solid3d != null)
            {
                // Keep 3DSOLID lightweight in a hover command; do not calculate MassProperties.
                return;
            }

            var face = entity as Face;
            if (face != null)
            {
                text.Add(Lang.T("Vertex1"), P(face.GetVertexAt(0)));
                text.Add(Lang.T("Vertex2"), P(face.GetVertexAt(1)));
                text.Add(Lang.T("Vertex3"), P(face.GetVertexAt(2)));
                text.Add(Lang.T("Vertex4"), P(face.GetVertexAt(3)));
                return;
            }

            var point = entity as DBPoint;
            if (point != null)
            {
                text.Add(Lang.T("Coordinates"), P(point.Position));
                return;
            }

            var xline = entity as Xline;
            if (xline != null)
            {
                text.Add(Lang.T("BasePoint"), P(xline.BasePoint));
                text.Add(Lang.T("Direction"), V(xline.UnitDir));
                return;
            }

            var ray = entity as Ray;
            if (ray != null)
            {
                text.Add(Lang.T("BasePoint"), P(ray.BasePoint));
                text.Add(Lang.T("Direction"), V(ray.UnitDir));
                return;
            }

            var polyline2d = entity as Polyline2d;
            if (polyline2d != null)
            {
                text.Add(Lang.T("Closed"), YesNo(polyline2d.Closed));
                text.Add(Lang.T("Length"), CurveLength(polyline2d));
                if (polyline2d.Closed)
                {
                    text.Add(Lang.T("Area"), SafeNumber(() => polyline2d.Area));
                }
                return;
            }

            var polyline3d = entity as Polyline3d;
            if (polyline3d != null)
            {
                text.Add(Lang.T("Closed"), YesNo(polyline3d.Closed));
                text.Add(Lang.T("Length"), CurveLength(polyline3d));
                return;
            }

            var raster = entity as RasterImage;
            if (raster != null)
            {
                text.Add(Lang.T("ImageWidth"), N(raster.ImageWidth));
                text.Add(Lang.T("ImageHeight"), N(raster.ImageHeight));
                return;
            }

            var curve = entity as Curve;
            if (curve != null)
            {
                text.Add(Lang.T("StartPoint"), SafePoint(() => curve.StartPoint));
                text.Add(Lang.T("EndPoint"), SafePoint(() => curve.EndPoint));
                text.Add(Lang.T("Length"), CurveLength(curve));
                text.Add(Lang.T("Closed"), YesNo(curve.Closed));
                if (curve.Closed)
                {
                    text.Add(Lang.T("Area"), SafeNumber(() => curve.Area));
                }
                return;
            }

            if (string.Equals(dxfName, "SOLID", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(dxfName, "TRACE", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(dxfName, "BODY", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(dxfName, "OLE2FRAME", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(dxfName, "OLEFRAME", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(dxfName, "SHAPE", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(dxfName, "TOLERANCE", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(dxfName, "ACAD_PROXY_ENTITY", StringComparison.OrdinalIgnoreCase))
            {
                // The generic header/layer/handle above is intentionally retained for these entities.
                return;
            }
        }

        private static string GetDisplayType(Entity entity, string dxfName)
        {
            if (entity is Line) return Lang.T("TypeLine");
            if (entity is Circle) return Lang.T("TypeCircle");
            if (entity is Arc) return Lang.T("TypeArc");
            if (entity is Polyline) return Lang.T("TypeLwPolyline");
            if (entity is BlockReference) return Lang.T("TypeInsert");
            if (entity is AttributeReference) return Lang.T("TypeAttribute");
            if (entity is AttributeDefinition) return Lang.T("TypeAttributeDefinition");
            if (entity is DBText) return Lang.T("TypeText");
            if (entity is MText) return Lang.T("TypeMText");
            if (entity is Dimension) return Lang.T("TypeDimension");
            if (entity is Ellipse) return Lang.T("TypeEllipse");
            if (entity is Hatch) return Lang.T("TypeHatch");
            if (entity is Leader) return Lang.T("TypeLeader");
            if (entity is Spline) return Lang.T("TypeSpline");
            if (entity is Region) return Lang.T("TypeRegion");
            if (entity is Solid3d) return Lang.T("TypeSolid3d");
            if (entity is Face) return Lang.T("TypeFace3d");
            if (entity is DBPoint) return Lang.T("TypePoint");
            if (entity is Xline) return Lang.T("TypeXline");
            if (entity is Ray) return Lang.T("TypeRay");
            if (entity is Polyline2d) return Lang.T("TypePolyline2d");
            if (entity is Polyline3d) return Lang.T("TypePolyline3d");
            if (entity is RasterImage) return Lang.T("TypeImage");
            return string.IsNullOrWhiteSpace(dxfName) ? entity.GetType().Name : dxfName;
        }

        private static string GetBlockName(BlockReference block, Transaction transaction)
        {
            try
            {
                ObjectId recordId = block.IsDynamicBlock ? block.DynamicBlockTableRecord : block.BlockTableRecord;
                var record = transaction.GetObject(recordId, OpenMode.ForRead, false) as BlockTableRecord;
                return record != null ? record.Name : string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }

        private static string GetTextStyleName(ObjectId styleId, Transaction transaction)
        {
            try
            {
                var style = transaction.GetObject(styleId, OpenMode.ForRead, false) as TextStyleTableRecord;
                return style != null ? style.Name : string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }

        private static string GetDimStyleName(ObjectId styleId, Transaction transaction)
        {
            try
            {
                var style = transaction.GetObject(styleId, OpenMode.ForRead, false) as DimStyleTableRecord;
                return style != null ? style.Name : string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }

        private static string CurveLength(Curve curve)
        {
            return SafeNumber(() =>
            {
                double start = curve.GetDistanceAtParameter(curve.StartParam);
                double end = curve.GetDistanceAtParameter(curve.EndParam);
                return Math.Abs(end - start);
            });
        }

        private static string OneLine(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return string.Empty;
            }

            return value.Replace("\r", " ").Replace("\n", " ");
        }

        private static string YesNo(bool value)
        {
            return value ? Lang.T("Yes") : Lang.T("No");
        }

        private static string N(double value)
        {
            return value.ToString("0." + new string('#', Precision), CultureInfo.InvariantCulture);
        }

        private static string Degree(double radians)
        {
            double degrees = radians * 180.0 / Math.PI;
            return N(degrees) + "°";
        }

        private static string P(Point3d point)
        {
            return "X=" + N(point.X) + ", Y=" + N(point.Y) + ", Z=" + N(point.Z);
        }

        private static string V(Vector3d vector)
        {
            return "X=" + N(vector.X) + ", Y=" + N(vector.Y) + ", Z=" + N(vector.Z);
        }

        private static string Safe(Func<string> getter)
        {
            try
            {
                return getter();
            }
            catch
            {
                return string.Empty;
            }
        }

        private static string SafeNumber(Func<double> getter)
        {
            try
            {
                return N(getter());
            }
            catch
            {
                return string.Empty;
            }
        }

        private static string SafePoint(Func<Point3d> getter)
        {
            try
            {
                return P(getter());
            }
            catch
            {
                return string.Empty;
            }
        }
    }
}
