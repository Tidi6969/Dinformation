using System;
using System.Collections.Generic;
using System.Text;
using Gssoft.Gscad.ApplicationServices;
using Gssoft.Gscad.DatabaseServices;
using Gssoft.Gscad.EditorInput;
using DCAD.Dinformation.Core;
using DCAD.Dinformation.Data;
using DCAD.Dinformation.UI;

namespace DCAD.Dinformation.Information
{
    internal sealed class InformationSession : IDisposable
    {
        private readonly Document _document;
        private readonly Editor _editor;
        private readonly ObjectInformationService _informationService;
        private readonly DtagInformationService _dtagService;

        private const int TooltipCacheLimit = 64;
        private ObjectId _highlightedId = ObjectId.Null;
        private readonly Dictionary<ObjectId, string> _tooltipCache = new Dictionary<ObjectId, string>();
        private bool _subscribed;
        private bool _forcedPickEnabled;
        private bool _monitorErrorLogged;
        private bool _highlightErrorLogged;
        private bool _unhighlightErrorLogged;

        public InformationSession(Document document)
        {
            _document = document ?? throw new ArgumentNullException(nameof(document));
            _editor = document.Editor;
            _informationService = new ObjectInformationService();
            _dtagService = new DtagInformationService();
        }

        public void Run()
        {
            Subscribe();
            EnableForcedPick();
            RuntimeLog.Info("Command session started. Drawing=" + (_document.Name ?? string.Empty) + "; PickMode=ForcedPick");

            try
            {
                var options = new PromptPointOptions(UiText.StartPrompt)
                {
                    AllowNone = true,
                    UseBasePoint = false,
                    UseDashedLine = false
                };

                _editor.GetPoint(options);
            }
            finally
            {
                ClearHighlight();
                DisableForcedPick();
                RuntimeLog.Info("Command session ended.");
            }
        }

        private void OnPointMonitor(object sender, PointMonitorEventArgs e)
        {
            try
            {
                ObjectId objectId = ResolveHoveredObjectId(e);
                if (!CanOpen(objectId))
                {
                    if (!_highlightedId.IsNull)
                    {
                        ClearHighlight();
                    }
                    return;
                }

                // Highlight first, using the entity already picked by the CAD engine.
                // Keep CAD PICKBOX/OSNAP settings unchanged and do not do a second hit test.
                SetHighlight(objectId);

                string tooltip;
                if (!_tooltipCache.TryGetValue(objectId, out tooltip))
                {
                    // Re-entering an object (even across empty space) must not repeat
                    // the expensive geometry/property inspection in this command.
                    tooltip = _informationService.Build(_document.Database, objectId);
                    // Additional Dtag content is computed once per entity, not on every
                    // PointMonitor movement. Native V23 picking and highlight are unchanged.
                    try
                    {
                        string dtag = _dtagService.Build(_document.Database, objectId);
                        if (!string.IsNullOrWhiteSpace(dtag))
                        {
                            tooltip = BuildNativeTooltip(tooltip, dtag);
                        }
                    }
                    catch (System.Exception exception)
                    {
                        RuntimeLog.Error("Dtag XData read failed; native CAD tooltip remains available.", exception);
                    }
                    if (_tooltipCache.Count >= TooltipCacheLimit)
                    {
                        _tooltipCache.Clear();
                    }
                    _tooltipCache[objectId] = tooltip;
                }

                if (!string.IsNullOrWhiteSpace(tooltip))
                {
                    e.AppendToolTipText(tooltip);
                }
            }
            catch (System.Exception exception)
            {
                if (!_monitorErrorLogged)
                {
                    _monitorErrorLogged = true;
                    RuntimeLog.Error("PointMonitor failed. Further PointMonitor errors in this command are suppressed.", exception);
                }
            }
        }

        private static string BuildNativeTooltip(string cad, string dtag)
        {
            var result = new StringBuilder();
            if (!string.IsNullOrWhiteSpace(cad))
            {
                result.Append(Lang.T("CadTableTitle")).AppendLine();
                result.Append(WrapNativeLines(cad));
            }

            if (result.Length != 0) result.AppendLine().AppendLine();
            result.Append(Lang.T("DtagTableTitle")).AppendLine();
            result.Append(WrapNativeLines(dtag));
            return result.ToString();
        }

        // Native CAD tooltips choose their own window size. Soft-wrap long
        // lines so coordinates/XData values do not disappear off the right edge.
        // All characters are retained. Height is still controlled by CAD/screen.
        private static string WrapNativeLines(string text)
        {
            const int maxColumns = 56;
            if (string.IsNullOrEmpty(text)) return string.Empty;
            string[] lines = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            var result = new StringBuilder(text.Length + 32);
            for (int lineIndex = 0; lineIndex < lines.Length; lineIndex++)
            {
                if (lineIndex != 0) result.AppendLine();
                string line = lines[lineIndex];
                int begin = 0;
                while (begin < line.Length)
                {
                    int end = begin;
                    int columns = 0;
                    while (end < line.Length)
                    {
                        int glyphWidth = IsWideGlyph(line[end]) ? 2 : 1;
                        if (columns + glyphWidth > maxColumns) break;
                        columns += glyphWidth;
                        end++;
                    }
                    if (end == line.Length)
                    {
                        result.Append(line, begin, end - begin);
                        break;
                    }
                    if (end == begin) end++; // Preserve even an unusual glyph.
                    // Prefer a boundary near the line end; never drop a delimiter.
                    int split = end;
                    for (int j = end - 1; j > begin + 24; j--)
                    {
                        char ch = line[j];
                        if (ch == ' ' || ch == ',' || ch == ';' || ch == '|')
                        {
                            split = j + 1;
                            break;
                        }
                    }
                    // Do not split Unicode surrogate pairs.
                    if (split < line.Length && split > begin &&
                        char.IsHighSurrogate(line[split - 1]) && char.IsLowSurrogate(line[split]))
                        split--;
                    if (split <= begin) split = end;
                    result.Append(line, begin, split - begin).AppendLine();
                    begin = split;
                }
            }
            return result.ToString();
        }

        private static bool IsWideGlyph(char ch)
        {
            return ch >= '\u2E80' && (ch <= '\u9FFF' ||
                (ch >= '\uAC00' && ch <= '\uD7AF') ||
                (ch >= '\uF900' && ch <= '\uFAFF'));
        }

        private ObjectId ResolveHoveredObjectId(PointMonitorEventArgs e)
        {
            if (e == null || e.Context == null)
            {
                return ObjectId.Null;
            }

            FullSubentityPath[] paths = e.Context.GetPickedEntities();
            if (paths == null || paths.Length == 0)
            {
                return ObjectId.Null;
            }

            // FullSubentityPath is ordered from the outermost container toward the picked entity.
            // Returning ids[0] mirrors the reference LISP: nested geometry reports its outer block;
            // a normal entity has a one-item path and therefore reports itself.
            for (int p = 0; p < paths.Length; p++)
            {
                ObjectId[] ids = paths[p].GetObjectIds();
                if (ids == null || ids.Length == 0)
                {
                    continue;
                }

                for (int i = 0; i < ids.Length; i++)
                {
                    if (CanOpen(ids[i]))
                    {
                        return ids[i];
                    }
                }
            }

            return ObjectId.Null;
        }

        private void SetHighlight(ObjectId objectId)
        {
            if (objectId == _highlightedId)
            {
                return;
            }

            // Switching objects takes one read-only transaction, not two.
            ObjectId previousId = _highlightedId;
            _highlightedId = ObjectId.Null;
            try
            {
                using (Transaction transaction = _document.Database.TransactionManager.StartOpenCloseTransaction())
                {
                    if (CanOpen(previousId))
                    {
                        try
                        {
                            var previous = transaction.GetObject(previousId, OpenMode.ForRead, false) as Entity;
                            if (previous != null)
                            {
                                previous.Unhighlight();
                            }
                        }
                        catch (System.Exception exception)
                        {
                            if (!_unhighlightErrorLogged)
                            {
                                _unhighlightErrorLogged = true;
                                RuntimeLog.Error("Unhighlight failed. Further unhighlight errors in this command are suppressed. ObjectId=" + previousId, exception);
                            }
                        }
                    }

                    try
                    {
                        var entity = transaction.GetObject(objectId, OpenMode.ForRead, false) as Entity;
                        if (entity != null)
                        {
                            entity.Highlight();
                            _highlightedId = objectId;
                        }
                    }
                    catch (System.Exception exception)
                    {
                        if (!_highlightErrorLogged)
                        {
                            _highlightErrorLogged = true;
                            RuntimeLog.Error("Highlight failed. Further highlight errors in this command are suppressed. ObjectId=" + objectId, exception);
                        }
                    }

                    transaction.Commit();
                }
            }
            catch (System.Exception exception)
            {
                if (!_highlightErrorLogged)
                {
                    _highlightErrorLogged = true;
                    RuntimeLog.Error("Highlight transaction failed. Further errors in this command are suppressed. ObjectId=" + objectId, exception);
                }
                _highlightedId = ObjectId.Null;
            }
        }

        private void ClearHighlight()
        {
            ObjectId id = _highlightedId;
            _highlightedId = ObjectId.Null;
            if (!CanOpen(id))
            {
                return;
            }

            try
            {
                using (Transaction transaction = _document.Database.TransactionManager.StartOpenCloseTransaction())
                {
                    var entity = transaction.GetObject(id, OpenMode.ForRead, false) as Entity;
                    if (entity != null)
                    {
                        entity.Unhighlight();
                    }

                    transaction.Commit();
                }
            }
            catch (System.Exception exception)
            {
                if (!_unhighlightErrorLogged)
                {
                    _unhighlightErrorLogged = true;
                    RuntimeLog.Error("Unhighlight failed. Further unhighlight errors in this command are suppressed. ObjectId=" + id, exception);
                }
            }
        }

        private void OnDatabaseObjectModified(object sender, ObjectEventArgs e)
        {
            try
            {
                if (e != null && e.DBObject != null)
                {
                    _tooltipCache.Remove(e.DBObject.ObjectId);
                }
            }
            catch (System.Exception exception)
            {
                RuntimeLog.Error("Tooltip cache invalidation failed.", exception);
            }
        }

        private void EnableForcedPick()
        {
            try
            {
                _editor.TurnForcedPickOn();
                _forcedPickEnabled = true;
            }
            catch (System.Exception exception)
            {
                _forcedPickEnabled = false;
                RuntimeLog.Error("TurnForcedPickOn failed. Command continues with normal PointMonitor picking.", exception);
            }
        }

        private void DisableForcedPick()
        {
            if (!_forcedPickEnabled)
            {
                return;
            }

            _forcedPickEnabled = false;
            try
            {
                _editor.TurnForcedPickOff();
            }
            catch (System.Exception exception)
            {
                RuntimeLog.Error("TurnForcedPickOff failed.", exception);
            }
        }

        private static bool CanOpen(ObjectId objectId)
        {
            return !objectId.IsNull && objectId.IsValid && !objectId.IsErased;
        }

        private void Subscribe()
        {
            if (_subscribed)
            {
                return;
            }

            _editor.PointMonitor += OnPointMonitor;
            _document.Database.ObjectModified += OnDatabaseObjectModified;
            _subscribed = true;
        }

        private void Unsubscribe()
        {
            if (!_subscribed)
            {
                return;
            }

            _editor.PointMonitor -= OnPointMonitor;
            _document.Database.ObjectModified -= OnDatabaseObjectModified;
            _subscribed = false;
        }

        public void Dispose()
        {
            ClearHighlight();
            DisableForcedPick();
            Unsubscribe();
        }
    }
}
