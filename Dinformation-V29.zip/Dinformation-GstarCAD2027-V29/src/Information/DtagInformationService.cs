using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;
using Gssoft.Gscad.DatabaseServices;
using DCAD.Dinformation.Core;
using DCAD.Dinformation.UI;

namespace DCAD.Dinformation.Information
{
    // Read-only decoder for Dtag V54: RegApp my_tag, 1000 string payloads.
    // Group detection and token positions mirror Dtagchange V54, not guessed from entity geometry.
    internal sealed class DtagInformationService
    {
        private const string RegApp = "my_tag";

        public string Build(Database database, ObjectId objectId)
        {
            if (database == null || objectId.IsNull || !objectId.IsValid || objectId.IsErased)
                return string.Empty;

            using (Transaction tr = database.TransactionManager.StartOpenCloseTransaction())
            {
                Entity entity = tr.GetObject(objectId, OpenMode.ForRead, false) as Entity;
                if (entity == null) return string.Empty;

                // Reads this application's XData only. No UpgradeOpen and no write.
                using (ResultBuffer buffer = entity.GetXDataForApplication(RegApp))
                {
                    if (buffer == null) return string.Empty;
                    TypedValue[] records = buffer.AsArray();
                    var strings = new List<string>();
                    bool inTag = false;
                    for (int i = 0; i < records.Length; i++)
                    {
                        if (records[i].TypeCode == 1001)
                        {
                            if (inTag) break;
                            inTag = string.Equals(records[i].Value as string, RegApp, StringComparison.OrdinalIgnoreCase);
                        }
                        else if (inTag && records[i].TypeCode == 1000)
                        {
                            strings.Add(records[i].Value as string ?? string.Empty);
                        }
                    }
                    if (!inTag || strings.Count == 0) return string.Empty;
                    tr.Commit();
                    return Format(strings);
                }
            }
        }

        private static string Format(List<string> strings)
        {
            int nameIndex = IndexOf(strings, "NAME");
            int materialIndex = IndexOf(strings, "MATER");
            string nameData = After(strings, nameIndex);
            string[] tokens = Tokens(nameData);
            int group = -1;
            int parsedGroup;
            if (tokens.Length > 0 && int.TryParse(tokens[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out parsedGroup))
                group = parsedGroup;

            // Dtag V54 treats 5/7 by the relative positions of NAME and MATER.
            if (nameIndex >= 0 && (group == 5 || group == 7))
                group = materialIndex < 0 || materialIndex < nameIndex ? 5 : 7;

            var text = new TooltipFormatter();
            text.Add("RegApp", RegApp);
            string groupName;
            switch (group)
            {
                case 1: groupName = Lang.T("TagGroupHole"); break;
                case 3: groupName = Lang.T("TagGroupStandard"); break;
                case 5: groupName = Lang.T("TagGroupSpecialHole"); break;
                case 7: groupName = Lang.T("TagGroupInsert"); break;
                case 8: groupName = Lang.T("TagGroupPlate"); break;
                default: groupName = Lang.T("TagGroupOther"); break;
            }
            text.Add(Lang.T("TagGroup"), group >= 0 ? group.ToString(CultureInfo.InvariantCulture) + " — " + groupName : groupName);

            switch (group)
            {
                case 1:
                    Field(text, "TagName", tokens, 1);
                    Field(text, "Diameter", tokens, 2);
                    Field(text, "TagDepth", tokens, 3);
                    Field(text, "TagGaps", tokens, 4);
                    Note(text, "TagNote", tokens, 5);
                    SplitOther(text, tokens, 6);
                    Extras(text, tokens, 7);
                    break;
                case 5:
                    Field(text, "TagName", tokens, 1);
                    Field(text, "TagNumber", tokens, 2);
                    Field(text, "TagDepth", tokens, 3);
                    Field(text, "TagGaps", tokens, 4);
                    Note(text, "TagNote", tokens, 5);
                    SplitOther(text, tokens, 6);
                    Extras(text, tokens, 7);
                    break;
                case 3:
                    Field(text, "TagStyle", tokens, 1);
                    Field(text, "Diameter", tokens, 2);
                    Field(text, "Length", tokens, 3);
                    Field(text, "TagSmallDiameter", tokens, 4);
                    Field(text, "TagSmallLength", tokens, 5);
                    Field(text, "TagEffectiveLength", tokens, 6);
                    Note(text, "TagNote", tokens, 7);
                    Field(text, "TagOther1", tokens, 8);
                    Extras(text, tokens, 9);
                    // Dtag V54 stores Standard Part's 18 optional fields as separate 1000 values.
                    if (nameIndex >= 0 && nameIndex + 2 < strings.Count)
                        for (int i = nameIndex + 2; i < strings.Count; i++)
                            ExtraField(text, i - (nameIndex + 1), strings[i]);
                    break;
                case 7:
                    Field(text, "TagStyle", tokens, 1);
                    Field(text, "TagNumber", tokens, 2);
                    Field(text, "Length", tokens, 3);
                    if (tokens.Length > 4) ExtraField(text, 5, tokens[4]); // Dtag V54 preserves this legacy token without a defined field name.
                    Note(text, "TagNote", tokens, 5);
                    Field(text, "TagOther1", tokens, 6);
                    Field(text, "TagOther2", tokens, 7);
                    Extras(text, tokens, 8);
                    string[] mater = Tokens(After(strings, materialIndex));
                    Field(text, "TagMaterial", mater, 0);
                    Field(text, "TagHeat", mater, 1);
                    Extras(text, mater, 2);
                    text.Add(Lang.T("Length") + " (LENGTH)", Decode(After(strings, IndexOf(strings, "LENGTH")), false));
                    break;
                case 8:
                    Field(text, "TagName", tokens, 1);
                    Field(text, "TagThickness", tokens, 2);
                    Field(text, "TagMaterial", tokens, 3);
                    Field(text, "TagHeat", tokens, 4);
                    Field(text, "TagMaterialPrice", tokens, 5);
                    Field(text, "TagHeatPrice", tokens, 6);
                    Field(text, "TagDensity", tokens, 7);
                    Field(text, "TagOther1", tokens, 8);
                    Field(text, "TagOther2", tokens, 9);
                    Extras(text, tokens, 10);
                    text.Add("MATER", Decode(After(strings, materialIndex), false));
                    text.Add("LENGTH", Decode(After(strings, IndexOf(strings, "LENGTH")), false));
                    break;
                default:
                    // Unknown group: show source payload without guessing a field schema.
                    for (int i = 0; i < strings.Count; i++)
                        ExtraField(text, i + 1, strings[i]);
                    return text.ToString();
            }

            // Preserve unknown application fields (other than Dtag's recognized labels).
            if (group != 3)
                for (int i = 0; i + 1 < strings.Count; i++)
                    if (!EqualsLabel(strings[i], "NAME") && !EqualsLabel(strings[i], "MATER") && !EqualsLabel(strings[i], "LENGTH") &&
                        (i == 0 || (!EqualsLabel(strings[i - 1], "NAME") && !EqualsLabel(strings[i - 1], "MATER") && !EqualsLabel(strings[i - 1], "LENGTH"))))
                        ExtraField(text, i + 1, strings[i]);
            return text.ToString();
        }

        private static void Field(TooltipFormatter text, string label, string[] tokens, int index)
        {
            if (index < tokens.Length) text.Add(Lang.T(label), Decode(tokens[index], false));
        }
        private static void Note(TooltipFormatter text, string label, string[] tokens, int index)
        {
            if (index < tokens.Length) text.Add(Lang.T(label), Decode(tokens[index], true));
        }
        private static void ExtraField(TooltipFormatter text, int index, string value)
        {
            text.Add(Lang.F("TagFieldNumber", index), value == "." ? string.Empty : value);
        }
        private static void Extras(TooltipFormatter text, string[] tokens, int from)
        {
            for (int i = from; i < tokens.Length; i++) ExtraField(text, i + 1, Decode(tokens[i], false));
        }
        private static void SplitOther(TooltipFormatter text, string[] tokens, int index)
        {
            if (index >= tokens.Length) return;
            int split = tokens[index].IndexOf('$');
            if (split < 0) { text.Add(Lang.T("TagOther1"), Decode(tokens[index], false)); return; }
            text.Add(Lang.T("TagOther1"), Decode(tokens[index].Substring(0, split), false));
            text.Add(Lang.T("TagOther2"), Decode(tokens[index].Substring(split + 1), false));
        }
        private static string Decode(string value, bool note)
        {
            if (string.IsNullOrWhiteSpace(value) || value == "." || value == "..") return string.Empty;
            return note ? value.Replace('$', ' ') : value.Replace('&', ' ');
        }
        private static bool EqualsLabel(string value, string label)
        {
            return string.Equals(value, label, StringComparison.OrdinalIgnoreCase);
        }
        private static int IndexOf(List<string> data, string key)
        {
            for (int i = 0; i < data.Count; i++) if (EqualsLabel(data[i], key)) return i;
            return -1;
        }
        private static string After(List<string> data, int index)
        {
            return index >= 0 && index + 1 < data.Count ? data[index + 1] : string.Empty;
        }
        private static string[] Tokens(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return new string[0];
            var result = new List<string>();
            string[] parts = Regex.Split(value.Trim(), @"\s+");
            for (int i = 0; i < parts.Length; i++)
            {
                string current = parts[i];
                if (current.EndsWith(".", StringComparison.Ordinal) && i + 1 < parts.Length && Regex.IsMatch(parts[i+1], @"^\d+$"))
                    current += parts[++i]; // Dtag V54 joins numeric fragments such as "0." + "000".
                if (current.Length != 0) result.Add(current);
            }
            return result.ToArray();
        }
    }
}
