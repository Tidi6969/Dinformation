@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist "log" mkdir "log"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Buildtime\Build_Release.ps1"
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (color 0A& echo [Dinformation GstarCAD 2027 V29] BUILD PASS. DLL: %~dp0bin\DinformationG27.dll) else (color 0C& echo [Dinformation GstarCAD 2027 V29] BUILD FAIL. See log\Build-V29.log)
if /I not "%~1"=="/nopause" (echo.& echo Press any key to close...& pause >nul)
exit /b %RC%
